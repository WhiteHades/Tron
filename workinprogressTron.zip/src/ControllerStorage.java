import java.sql.*;
import java.util.*;

public class ControllerStorage {
    public ModelStorage modelstorage;

    public ControllerStorage() {
        this.modelstorage = new ModelStorage();
    }
    public void updateScore (String name, int score) {
        modelstorage.updateScore(name, score);
    }
    public List<String> getHighScores() {
        return modelstorage.getHighScore();
    }

    public int getOverallScore(String playerName) {
        try (Connection conn = DriverManager.getConnection(modelstorage.getDbUrl(),
                modelstorage.getDbUser(),
                modelstorage.getDbPassword())) {
            String query = "SELECT score FROM highscores WHERE player_name = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setString(1, playerName);
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) return rs.getInt("score");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0; // Return 0 if the player is not found or in case of an error
    }
}
